invisible(Sys.setlocale('LC_ALL','English_United States.utf8'))
options(warn=1)
suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(svglite))
args <- commandArgs(trailingOnly = TRUE)
data_dir <- args[1]
out <- if (length(args) >= 2) args[2] else data_dir
settings_dir <- if (length(args) >= 3) args[3] else file.path(data_dir, 'inputs')
validation_dir <- if (length(args) >= 4) args[4] else file.path(out, 'validation')
dir.create(out, recursive = TRUE, showWarnings = FALSE)
dir.create(validation_dir, recursive = TRUE, showWarnings = FALSE)
stopifnot(dir.exists(out))
obs <- read.csv(file.path(data_dir,'plot_observed_KM.csv'),fileEncoding='UTF-8-BOM')
fit <- read.csv(file.path(data_dir,'plot_candidate_OS.csv'),fileEncoding='UTF-8-BOM')
families <- c('exponential','weibull','gompertz','lognormal','loglogistic','gengamma')
labels <- c('Exponential','Weibull','Gompertz','Log-normal','Log-logistic','Generalized\ngamma')
for (nm in c('obs','fit')) {
  z <- get(nm)
  z$arm <- factor(z$arm,levels=c('IP','PS'),labels=c('IP group','PS group'))
  z$family <- factor(z$family,levels=families,labels=labels)
  assign(nm,z)
}
fit$selected <- as.logical(fit$selected)
fit$at_boundary <- as.logical(fit$at_boundary)
sel <- unique(fit[fit$selected,c('arm','family')])
boundary <- unique(fit[fit$at_boundary,c('arm','family')])
sel$xmin <- 0; sel$xmax <- 75; sel$ymin <- 0; sel$ymax <- 1
sel$x <- 71; sel$y <- 0.955; sel$label <- 'Selected'
boundary$x <- 71; boundary$y <- 0.955; boundary$label <- '\u2020'
stopifnot(nrow(sel)==2,nrow(boundary)==1,nlevels(fit$family)==6)
blue <- '#3788B5'
red <- '#D43F45'
p <- ggplot() +
  geom_rect(data=sel,aes(xmin=xmin,xmax=xmax,ymin=ymin,ymax=ymax),
            fill=NA,colour='#303030',linewidth=1.0) +
  geom_line(data=obs,aes(time_months,survival,colour='Published KM (digitized)',
                       linetype='Published KM (digitized)'),linewidth=0.48) +
  geom_line(data=fit[!fit$selected,],aes(time_months,survival,colour='Fitted model',
                                      linetype='Fitted model'),linewidth=0.66) +
  geom_line(data=fit[fit$selected,],aes(time_months,survival,colour='Fitted model',
                                     linetype='Fitted model'),linewidth=0.92) +
  geom_text(data=sel,aes(x=x,y=y,label=label),family='Arial',
            size=2.9,fontface='bold',hjust=1,vjust=1,colour='#252525') +
  geom_text(data=boundary,aes(x=x,y=y,label=label),family='Arial',
            size=4,hjust=1,vjust=1,colour='#333333') +
  facet_grid(arm~family) +
  scale_colour_manual(values=c('Published KM (digitized)'=red,'Fitted model'=blue),
                      breaks=c('Published KM (digitized)','Fitted model'),name=NULL) +
  scale_linetype_manual(values=c('Published KM (digitized)'='longdash','Fitted model'='solid'),
                        breaks=c('Published KM (digitized)','Fitted model'),name=NULL) +
  scale_x_continuous(limits=c(0,75),breaks=c(0,24,48,72),expand=expansion(mult=0)) +
  scale_y_continuous(limits=c(0,1),breaks=c(0,0.5,1),labels=c('0.0','0.5','1.0'),
                     expand=expansion(mult=0)) +
  labs(x='Time (months)',y='Overall survival') +
  theme_bw(base_size=10,base_family='Arial') +
  theme(panel.grid.minor=element_blank(),
        panel.grid.major=element_line(colour='#ECECEC',linewidth=0.25),
        panel.border=element_rect(colour='#858585',fill=NA,linewidth=0.4),
        panel.spacing.x=grid::unit(2,'mm'),panel.spacing.y=grid::unit(3,'mm'),
        strip.background=element_rect(fill='#ECECEC',colour='#989898',linewidth=0.4),
        strip.text.x=element_text(size=9,face='bold',margin=margin(4,1,4,1)),
        strip.text.y=element_text(size=10,face='bold',angle=-90,margin=margin(4,4,4,4)),
        axis.text=element_text(size=8.5,colour='#333333'),
        axis.title=element_text(size=11),
        axis.title.x=element_text(margin=margin(t=7)),
        axis.title.y=element_text(margin=margin(r=7)),
        axis.ticks=element_line(colour='#777777',linewidth=0.35),
        axis.ticks.length=grid::unit(1.3,'mm'),
        legend.position='bottom',legend.text=element_text(size=9),
        legend.key.width=grid::unit(13,'mm'),legend.key.height=grid::unit(3.5,'mm'),
        legend.margin=margin(t=4,b=0),legend.box.margin=margin(0,0,0,0),
        plot.margin=margin(6,7,5,6)) +
  guides(colour=guide_legend(nrow=1,override.aes=list(linewidth=c(0.65,0.8))),
         linetype=guide_legend(nrow=1))
stem <- file.path(out,'Figure_S2_OS_Candidate_Model_Fits_EN')
ggsave(paste0(stem,'.pdf'),p,device=grDevices::cairo_pdf,width=228.6,height=140,units='mm',bg='white')
ggsave(paste0(stem,'.svg'),p,device=svglite::svglite,width=228.6,height=140,units='mm',bg='white')
ggsave(paste0(stem,'_600dpi.png'),p,device=ragg::agg_png,width=228.6,height=140,units='mm',dpi=600,bg='white')
cat('Saved PDF, SVG, PNG: ',stem,'\n')
