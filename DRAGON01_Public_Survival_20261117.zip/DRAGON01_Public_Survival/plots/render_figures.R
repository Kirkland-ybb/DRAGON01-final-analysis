if (.Platform$OS.type == 'windows') {
  invisible(Sys.setlocale('LC_ALL', 'English_United States.utf8'))
}
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop('Usage: Rscript plots/render_figures.R results_directory')
file_arg <- grep('^--file=', commandArgs(), value = TRUE)
root <- dirname(dirname(normalizePath(sub('^--file=', '', file_arg[1]))))
result <- normalizePath(args[1])
local_library <- file.path(root, '.work', 'r-library')
.libPaths(c(local_library, .libPaths()))
Sys.setenv(R_LIBS_USER = paste(.libPaths(), collapse = .Platform$path.sep))
rscript <- file.path(R.home('bin'), if (.Platform$OS.type == 'windows') 'Rscript.exe' else 'Rscript')
figures <- c('Figure2', 'Figure3', 'Figure4', 'FigureS2', 'FigureS3', 'FigureS4', 'FigureS5', 'FigureS6')
for (name in figures) {
  data_directory <- file.path(result, 'figure_data', name)
  if (!dir.exists(data_directory)) next
  figure_directory <- file.path(root, 'figures', name)
  settings_directory <- file.path(root, 'data', 'plot_settings', name)
  validation_directory <- file.path(result, 'validation', 'figures', name)
  script <- file.path(root, 'plots', paste0(name, '.R'))
  status <- system2(rscript, c('--vanilla', shQuote(script), shQuote(data_directory),
                              shQuote(figure_directory), shQuote(settings_directory),
                              shQuote(validation_directory)))
  if (status != 0) stop(paste('Figure rendering failed', name))
}
