invisible(Sys.setlocale('LC_ALL','English_United States.utf8'))
options(warn=1)
suppressPackageStartupMessages(library(ggplot2))
suppressPackageStartupMessages(library(cowplot))
cowplot::set_null_device('agg')
suppressPackageStartupMessages(library(svglite))
args <- commandArgs(trailingOnly = TRUE)
data_dir <- args[1]
out <- if (length(args) >= 2) args[2] else data_dir
settings_dir <- if (length(args) >= 3) args[3] else file.path(data_dir, 'inputs')
validation_dir <- if (length(args) >= 4) args[4] else file.path(out, 'validation')
dir.create(out, recursive = TRUE, showWarnings = FALSE)
dir.create(validation_dir, recursive = TRUE, showWarnings = FALSE)
stopifnot(dir.exists(out))
surv <- read.csv(file.path(data_dir,'plot_survival.csv'),fileEncoding='UTF-8-BOM')
death <- read.csv(file.path(data_dir,'plot_annual_death_steps.csv'),fileEncoding='UTF-8-BOM')
surv$arm <- factor(surv$arm,levels=c('IP','PS'),labels=c('IP group','Systemic therapy group'))
death$arm <- factor(death$arm,levels=c('IP','PS'),labels=c('IP group','Systemic therapy group'))
surv$endpoint <- factor(surv$endpoint,levels=c('OS','PFS'))
death$source <- factor(death$source,levels=c('Modelled OS','Matched population'))
colours <- c('IP group'='#3788B5','Systemic therapy group'='#D43F45')
common_theme <- theme_bw(base_size=10,base_family='Arial') +
  theme(panel.grid.minor=element_blank(),
        panel.grid.major=element_line(colour='#ECECEC',linewidth=0.28),
        panel.border=element_rect(colour='#858585',fill=NA,linewidth=0.4),
        axis.text=element_text(size=9,colour='#333333'),
        axis.title=element_text(size=10.5),
        axis.title.y=element_text(margin=margin(r=8)),
        axis.ticks=element_line(colour='#777777',linewidth=0.35),
        axis.ticks.length=grid::unit(1.4,'mm'),
        plot.title=element_text(size=11.5,face='bold',hjust=0.5,margin=margin(b=9)),
        legend.position='bottom',legend.text=element_text(size=9.5),
        legend.key.width=grid::unit(13,'mm'),legend.key.height=grid::unit(4,'mm'),
        legend.margin=margin(t=7,b=0),plot.margin=margin(7,8,3,5))
xscale <- scale_x_continuous(limits=c(0,40),breaks=c(0,10,20,30,40),expand=expansion(mult=0))
pa <- ggplot(surv,aes(time_years,survival,colour=arm,linetype=endpoint)) +
  geom_line(linewidth=0.8) +
  scale_colour_manual(values=colours,name=NULL) +
  scale_linetype_manual(values=c('OS'='solid','PFS'='longdash'),name=NULL) +
  xscale + scale_y_log10(limits=c(1e-7,1),breaks=c(1,1e-2,1e-4,1e-6),
      labels=c('100%','1%','0.01%','0.0001%'),expand=expansion(mult=0)) +
  labs(title='Long-term survival',x=NULL,y='Survival probability (log scale)') + common_theme +
  guides(colour='none',linetype=guide_legend(nrow=1,override.aes=list(colour='#444444',linewidth=0.8)))
pb <- ggplot(death,aes(time_years,probability,colour=arm,linetype=source)) +
  geom_step(linewidth=0.8,direction='hv') +
  scale_colour_manual(values=colours,name=NULL) +
  scale_linetype_manual(values=c('Modelled OS'='solid','Matched population'='longdash'),name=NULL) +
  xscale + scale_y_continuous(limits=c(0,.6),breaks=c(0,.2,.4,.6),
      labels=c('0%','20%','40%','60%'),expand=expansion(mult=0)) +
  labs(title='Annual mortality probability',x=NULL,y='Annual probability of death') + common_theme +
  guides(colour='none',linetype=guide_legend(nrow=1,override.aes=list(colour='#444444',linewidth=0.8)))
colour_legend <- cowplot::get_legend(pa +
  guides(colour=guide_legend(nrow=1,override.aes=list(linetype='solid',linewidth=.9)),linetype='none') +
  theme(legend.position='top',legend.margin=margin(0,0,0,0)))
panels <- cowplot::plot_grid(pa,pb,nrow=1,align='h',axis='tb',
   labels=c('A','B'),label_size=12,label_fontfamily='Arial',label_fontface='bold',
   label_x=0.005,label_y=0.99,hjust=0,vjust=1)
xlabel <- cowplot::ggdraw() + cowplot::draw_label('Time since treatment initiation (years)',
   x=.5,y=.5,fontfamily='Arial',size=10.5)
p <- cowplot::plot_grid(colour_legend,panels,xlabel,ncol=1,rel_heights=c(.065,.885,.05))
stem <- file.path(out,'Figure_S4_Long_Term_Survival_Background_Mortality_EN')
ggsave(paste0(stem,'.pdf'),p,device=grDevices::cairo_pdf,width=250,height=130,units='mm',bg='white')
ggsave(paste0(stem,'.svg'),p,device=svglite::svglite,width=250,height=130,units='mm',bg='white')
ggsave(paste0(stem,'_600dpi.png'),p,device=ragg::agg_png,width=250,height=130,units='mm',dpi=600,bg='white')
cat('Saved S4 vector PDF, editable SVG and 600 dpi PNG.\n')
