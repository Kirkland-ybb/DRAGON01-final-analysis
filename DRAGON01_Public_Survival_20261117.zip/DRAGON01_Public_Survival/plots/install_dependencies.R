args <- commandArgs(trailingOnly = TRUE)
file_arg <- grep('^--file=', commandArgs(), value = TRUE)
root <- dirname(dirname(normalizePath(sub('^--file=', '', file_arg[1]))))
library_directory <- file.path(root, '.work', 'r-library')
dir.create(library_directory, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(library_directory, .libPaths()))
packages <- c('ggplot2', 'cowplot', 'jsonlite', 'svglite', 'ragg')
if ('--check' %in% args) {
  available <- vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  if (!all(available)) {
    stop(paste('Install R dependencies with Rscript plots/install_dependencies.R. Missing',
               paste(packages[!available], collapse = ', ')))
  }
  print(vapply(packages, function(x) as.character(packageVersion(x)), character(1)))
} else {
  options(timeout = 120, repos = c(CRAN = 'https://mirrors.tuna.tsinghua.edu.cn/CRAN'))
  if (!requireNamespace('renv', quietly = TRUE)) {
    install.packages('renv', lib = library_directory)
  }
  renv::restore(project = root, library = library_directory,
                lockfile = file.path(root, 'renv.lock'), prompt = FALSE)
}
