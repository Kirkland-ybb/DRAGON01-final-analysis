class ContractError(ValueError):
    pass


class guard:
    ContractError = ContractError
