"""Explicit conditional-cost and event-loss evaluation for calculated rows."""

import numpy as np
from outcomes import summarize


def uniform_b(c, q, *, b, wtp, event_loss_PV):
    """b is a net incremental present-value cost per starting patient.

    It summarizes the stated unresolved between-arm cost condition. It does
    not assign a zero price to each unpriced component. Losses are two-arm
    present-value QALYs; unfavorable results remain in the denominator.
    """
    c = np.atleast_2d(np.asarray(c, float))
    q = np.atleast_2d(np.asarray(q, float))
    b = np.asarray(b, float)
    loss = np.asarray(event_loss_PV, float)
    if b.shape not in [(), (len(c),)] or not np.isfinite(b).all():
        raise ValueError("finite scalar or per-row b required")
    if (
        loss.shape not in [(2,), q.shape]
        or not np.isfinite(loss).all()
        or np.any(loss < 0)
    ):
        raise ValueError("explicit nonnegative two-arm QALY loss required")
    net = q - loss
    return dict(
        summary=summarize(c, net, wtp, b),
        INMB=wtp * (net[:, 0] - net[:, 1]) - (c[:, 0] - c[:, 1]) - b,
        Q_condition=net,
        within_aggregate_QALY_bound=bool(np.all(net >= 0)),
    )


def full_expression(
    c,
    q,
    beta,
    keys,
    *,
    residual_IP,
    residual_PS,
    timing_PV,
    followup_PV,
    overlap_PV,
    loss_PV,
    wtp
):
    """All 25 residuals and all two-arm adjustments must be explicit.

    This evaluates the cost expression. Physical feasibility, dated resources
    and ownership constraints must be satisfied by the supplied scenario.
    CAP150 is accounted for exactly once in its corresponding residual.
    """

    def vector(values):
        if not isinstance(values, dict) or set(values) != set(keys):
            raise ValueError("all 25 named cost residuals required")
        v = np.array([values[k] for k in keys], float)
        if not np.isfinite(v).all():
            raise ValueError("finite cost residuals required")
        return v

    residual = np.array([vector(residual_IP), vector(residual_PS)])

    def arms(x, nonnegative):
        x = np.asarray(x, float)
        if (
            x.shape not in [(2,), np.shape(c)]
            or not np.isfinite(x).all()
            or (nonnegative and np.any(x < 0))
        ):
            raise ValueError("invalid explicit two-arm adjustment")
        return x

    coefficients = np.asarray(beta, float)
    if coefficients.ndim == 2:
        coefficients = coefficients[None]
    extra = (
        np.einsum("nak,ak->na", coefficients, residual)
        + arms(timing_PV, False)
        + arms(followup_PV, True)
        - arms(overlap_PV, True)
    )
    result = uniform_b(
        c, q, b=extra[:, 0] - extra[:, 1], wtp=wtp, event_loss_PV=arms(loss_PV, True)
    )
    result.update(C_expression=np.asarray(c) + extra, joint_feasibility_certified=False)
    return result


def event_losses(gamma, *, affected_loss_IP, affected_loss_PS):
    """Five cumulative QALY losses per affected person in the declared order."""
    ip = np.asarray(affected_loss_IP, float)
    ps = np.asarray(affected_loss_PS, float)
    if (
        ip.shape != (5,)
        or ps.shape != (5,)
        or not np.isfinite([ip, ps]).all()
        or np.any(ip < 0)
        or np.any(ps < 0)
    ):
        raise ValueError(
            "five explicit nonnegative cumulative losses in each arm required"
        )
    return np.array([np.dot(gamma[0], ip), np.dot(gamma[1], ps)])
