"""Locations of scientific inputs, frozen targets and generated intermediates."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
PARAMETERS = DATA / "parameters"
DRAWS = DATA / "draws"
REFERENCE = ROOT / "reference" / "arrays"
PLOT_GRIDS = DATA / "plot_grids"
PLOT_SETTINGS = DATA / "plot_settings"
FIGURE_REFERENCE = ROOT / "reference" / "figure_values"
FIGURES = ROOT / "figures"


def work_directory(output):
    output = Path(output).resolve()
    return output.parent / ".work" / output.name
