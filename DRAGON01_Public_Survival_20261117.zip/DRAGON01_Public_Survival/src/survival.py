from io_utils import read_rows as read, read_json as js
from paths import DATA, PARAMETERS
from functools import lru_cache
from pathlib import Path
import math, copy
import numpy as np
from scipy import optimize, special, stats
from distributions import logs, sf, numerical_hessian
from reconstruction import km_values

FAMILIES = [
    "exponential",
    "weibull",
    "gompertz",
    "lognormal",
    "loglogistic",
    "gengamma",
]
TABLE = {
    (r["sex"], int(r["year"]), int(r["age"])): r
    for r in read(PARAMETERS / "mortality.csv")
}
ALLCAUSE_FITS = js(PARAMETERS / "allcause_fits.json")
BASE = js(PARAMETERS / "allcause_selection.json")
CFG = js(PARAMETERS / "survival_parameters.json")
ARCH = js(PARAMETERS / "survival_fits.json")


class Population:

    def __init__(self, age, wm, year=2023, mode="period"):
        self.age = age
        self.wm = wm
        self.year = year
        self.mode = mode
        self.max_months = (100 - age) * 12
        self.H = []
        self.hh = []
        for sex in ["Male", "Female"]:
            if mode == "period":
                lx = np.array(
                    [float(TABLE[sex, year, a]["lx"]) for a in range(age, 101)]
                )
                h = -np.log(lx[1:] / lx[:-1])
            else:
                h = np.array(
                    [
                        -np.log1p(-float(TABLE[sex, year + i, age + i]["qx"]))
                        for i in range(100 - age)
                    ]
                )
            self.hh.append(h / 12)
            self.H.append(np.r_[0, np.cumsum(h)])

    def evaluate(self, t):
        t = np.atleast_1d(np.asarray(t, float))
        if np.any(t < 0) or np.any(t > self.max_months + 1e-08):
            raise ValueError("outside closed-age life-table domain")
        ix = np.minimum(np.floor(t / 12).astype(int), len(self.hh[0]) - 1)
        rem = t - ix * 12
        h0 = self.hh[0][ix]
        h1 = self.hh[1][ix]
        m = np.exp(-self.H[0][ix] - h0 * rem)
        f = np.exp(-self.H[1][ix] - h1 * rem)
        ss = self.wm * m + (1 - self.wm) * f
        hp = (self.wm * m * h0 + (1 - self.wm) * f * h1) / ss
        return (-np.log(ss), hp)

    def spec(self):
        return dict(
            starting_age=self.age,
            male_fraction=self.wm,
            year=self.year,
            mode=self.mode,
            max_months=self.max_months,
        )


@lru_cache(maxsize=None)
def population(scenario, arm):
    age = 60 if arm == "IP" else 56
    wm = 80 / 148 if arm == "IP" else 38 / 74
    year = 2023
    mode = "period"
    if scenario == "P2019":
        year = 2019
    elif scenario == "COHORT2026":
        year = 2026
        mode = "cohort"
    elif scenario in ["COMMON59", "AGE48", "AGE66"]:
        age = {"COMMON59": 59, "AGE48": 48, "AGE66": 66}[scenario]
        wm = 118 / 222
    return Population(age, wm, year, mode)


def data(key):
    d = read(DATA / "reconstructed" / (key + "_pseudo_ipd.csv"))
    return (
        np.array([float(x["time_months"]) for x in d]),
        np.array([int(x["event"]) for x in d]),
    )


def likelihood(pa, family, t, e, Hpop, hpop):
    with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
        lf, ls = logs(family, pa, t)
        lh = lf - ls
        log_h_total = np.logaddexp(lh, np.log(hpop))
        val = np.sum(e * log_h_total + ls - Hpop)
    return float(-val) if np.isfinite(val) else 1e100


def fit(key, family, pop, warm=None):
    t, e = data(key)
    H, h = pop.evaluate(t)
    old = ALLCAUSE_FITS[key][family]
    starts = [old["params"]]
    if warm is not None:
        starts.insert(0, warm)
    mu = np.mean(np.log(t))
    sd = max(np.std(np.log(t)), 0.4)
    if family == "exponential":
        bounds = [(-12, 2)]
        starts.append([np.log(e.sum() / t.sum())])
    elif family in ["weibull", "loglogistic"]:
        bounds = [(-3, 3), (-3, 9)]
        starts += [[np.log(k), np.log(np.median(t))] for k in [0.6, 1.5, 2.5]]
    elif family == "lognormal":
        bounds = [(-3, 9), (-4, 3)]
        starts += [[mu, np.log(sd)], [np.log(np.median(t)), 0]]
    elif family == "gompertz":
        bounds = [(-12, 2), (0, 0.2)]
        starts = [[p[0], max(p[1], 0)] for p in starts]
        starts += [[np.log(e.sum() / t.sum()), g] for g in [0, 0.01, 0.03]]
    else:
        bounds = [(-3, 9), (-4, 3), (-4, 4)]
        starts += [[mu, np.log(sd), q] for q in [-2, -1, -0.4, 0.4, 1, 2]]
    obj = lambda p: likelihood(p, family, t, e, H, h)
    runs = []
    for p in starts:
        run = optimize.minimize(
            obj,
            p,
            method="L-BFGS-B",
            bounds=bounds,
            options=dict(maxiter=1600, ftol=2e-12, gtol=1e-06),
        )
        runs.append(run)
    best = min(runs, key=lambda a: a.fun)
    other = optimize.minimize(
        obj,
        best.x,
        method="Nelder-Mead",
        options=dict(maxiter=2500, xatol=1e-08, fatol=1e-09),
    )
    if other.fun < best.fun and all(
        (lo <= v <= hi for v, (lo, hi) in zip(other.x, bounds))
    ):
        best = other
    at_boundary = any(
        (
            abs(v - lo) < 1e-05 or abs(v - hi) < 1e-05
            for v, (lo, hi) in zip(best.x, bounds)
        )
    )
    try:
        hh = numerical_hessian(obj, best.x)
        eig = np.linalg.eigvalsh(hh)
        cov = np.linalg.inv(hh) if np.all(eig > 1e-07) and (not at_boundary) else None
    except Exception:
        eig = np.array([])
        cov = None
    grid = np.linspace(0, 72, 721)
    s = prediction(family, best.x, pop, grid)[0]
    emp = km_values(np.column_stack([t, e]), grid)
    g60 = grid <= 60
    med = optimize.brentq(
        lambda tm: prediction(family, best.x, pop, [tm])[0][0] - 0.5, 1e-08, 120.0
    )
    return dict(
        curve=key,
        family=family,
        params=best.x.tolist(),
        covariance=None if cov is None else cov.tolist(),
        information_eigenvalues=eig.tolist(),
        n=len(t),
        events=int(e.sum()),
        log_likelihood_full=-float(best.fun),
        AIC=2 * len(best.x) + 2 * float(best.fun),
        BIC=len(best.x) * np.log(len(t)) + 2 * float(best.fun),
        optimizer_success=bool(best.success),
        at_boundary=at_boundary,
        positive_information=cov is not None,
        rmse_0_60=float(np.sqrt(np.mean((s[g60] - emp[g60]) ** 2))),
        rmse_0_72=float(np.sqrt(np.mean((s - emp) ** 2))),
        max_abs_error_0_72=float(np.max(np.abs(s - emp))),
        median_months=float(med),
        population=pop.spec(),
        fixed_expected_cumulative_hazard_sum=float(H.sum()),
        multistart_nll_min=float(min((x.fun for x in runs))),
        multistart_nll_max=float(max((x.fun for x in runs))),
    )


def prediction(family, pa, pop, t):
    H, h = pop.evaluate(t)
    lf, ls = logs(family, pa, t)
    return (np.exp(ls - H), h + np.exp(lf - ls))


def select_pair(recs, pop):
    grid = np.unique(
        np.r_[
            0.0,
            np.geomspace(1e-08, 1.0, 1500),
            np.linspace(
                0, min(480, pop.max_months), int(min(480, pop.max_months) * 20) + 1
            ),
        ]
    )
    good = {}
    for endpoint in ["OS", "PFS"]:
        rr = [
            r
            for r in recs
            if r["curve"].startswith(endpoint + "_")
            and r["optimizer_success"]
            and r["positive_information"]
            and (not r["at_boundary"])
        ]
        if not rr:
            raise ValueError("no eligible " + endpoint)
        a = min((r["AIC"] for r in rr))
        good[endpoint] = sorted(
            rr,
            key=lambda r: (
                0 if r["AIC"] <= a + 2 + 1e-08 else 1,
                len(r["params"]) if r["AIC"] <= a + 2 + 1e-08 else r["AIC"],
                r["AIC"],
            ),
        )
    pair = []
    chosen = None
    for osrec in good["OS"]:
        for pfrec in good["PFS"]:
            so = prediction(osrec["family"], osrec["params"], pop, grid)[0]
            sp = prediction(pfrec["family"], pfrec["params"], pop, grid)[0]
            pair.append(
                dict(
                    OS=osrec["family"],
                    PFS=pfrec["family"],
                    ordered=bool(np.max(sp - so) <= 1e-10),
                    max_PFS_minus_OS=float(np.max(sp - so)),
                    marginal_AIC_sum=osrec["AIC"] + pfrec["AIC"],
                    n_parameters=len(osrec["params"]) + len(pfrec["params"]),
                )
            )
            if pair[-1]["ordered"] and chosen is None:
                chosen = dict(OS=osrec["family"], PFS=pfrec["family"])
    if chosen is None:
        raise ValueError("No ordered pair")
    return (chosen, pair, good)


class FloorScenario:

    def __init__(self, arm, pop, horizon=480, after=75):
        self.arm = arm
        self.pop = pop
        self.horizon = min(horizon, pop.max_months)
        self.after = after
        self.os_family = BASE["OS_" + arm]
        self.os_pa = ALLCAUSE_FITS["OS_" + arm][self.os_family]["params"]

        def diff(t):
            _, hp = pop.evaluate([t])
            lf, ls = logs(self.os_family, self.os_pa, [t])
            return float(hp[0] - np.exp(lf - ls)[0])

        def Hdiff(t):
            H, _ = pop.evaluate(t)
            return H + logs(self.os_family, self.os_pa, t)[1]

        self.Hdiff = Hdiff
        self.diff = diff
        knots = sorted(
            set(
                [0.0, float(after), float(self.horizon)]
                + [float(i) for i in range(12, int(self.horizon), 12)]
            )
        )
        roots = []
        for a, b in zip(knots[:-1], knots[1:]):
            if b <= after:
                continue
            xx = np.linspace(a + 1e-07, b - 1e-07, 25)
            yy = np.array([diff(x) for x in xx])
            for j in range(len(xx) - 1):
                if yy[j] * yy[j + 1] < 0:
                    roots.append(
                        float(optimize.brentq(diff, xx[j], xx[j + 1], xtol=1e-10))
                    )
        self.knots = np.array(sorted(set(knots + roots)))
        self.active = []
        cum = [0.0]
        for a, b in zip(self.knots[:-1], self.knots[1:]):
            active = a >= after and diff((a + b) / 2) > 0
            self.active.append(active)
            inc = float(Hdiff([b])[0] - Hdiff([a])[0]) if active else 0.0
            if inc < -1e-09:
                raise ValueError("incorrect floor segment")
            cum.append(cum[-1] + inc)
        self.cum = np.array(cum)
        self.first_activation = next(
            (float(self.knots[i]) for i, a in enumerate(self.active) if a), None
        )

    def correction(self, t):
        t = np.atleast_1d(np.asarray(t, float))
        i = np.minimum(
            np.searchsorted(self.knots, t, side="right") - 1, len(self.active) - 1
        )
        a = self.knots[i]
        active = np.asarray(self.active)[i]
        return self.cum[i] + np.where(active, self.Hdiff(t) - self.Hdiff(a), 0.0)

    def predict(self, endpoint, t):
        key = endpoint + "_" + self.arm
        fam = BASE[key]
        pa = ALLCAUSE_FITS[key][fam]["params"]
        lf, ls = logs(fam, pa, t)
        h = np.exp(lf - ls)
        t = np.atleast_1d(np.asarray(t, float))
        _, hp = self.pop.evaluate(t)
        lfos, lsos = logs(self.os_family, self.os_pa, t)
        dh = np.where(t >= self.after, np.maximum(hp - np.exp(lfos - lsos), 0.0), 0.0)
        return (np.exp(ls - self.correction(t)), h + dh)


def survival(times_years, arm, scenario="BASE"):
    if arm not in ["IP", "PS"]:
        raise ValueError("arm must be IP or PS")
    conf = CFG["scenarios"][scenario]
    yrs = np.atleast_1d(np.asarray(times_years, float))
    if np.any(yrs < 0) or np.any(yrs > conf["max_years"]):
        raise ValueError("outside declared horizon / closed age domain")
    t = yrs * 12
    out = []
    pop = population(conf.get("fit_background", "P2023"), arm)
    for endpoint in ["OS", "PFS"]:
        key = endpoint + "_" + arm
        if conf["model"] == "original_allcause":
            s = sf(BASE[key], ALLCAUSE_FITS[key][BASE[key]]["params"], t)
        elif conf["model"] == "shared_tail_floor":
            s = FloorScenario(arm, pop).predict(endpoint, t)[0]
        else:
            sc = conf["fit_background"]
            fam = conf.get("override", {}).get(key, ARCH["selections"][sc][key])
            p = ARCH["results"][sc][key][fam]["params"]
            s = prediction(fam, p, pop, t)[0]
        out.append(s)
    os_, pf = out
    if np.max(pf - os_) > 1e-10:
        raise ValueError("PFS exceeds OS")
    return dict(OS=os_, PFS=pf, PF=pf, PD=os_ - pf, Death=1 - os_)
