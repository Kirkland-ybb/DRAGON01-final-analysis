"""Reconstruct marginal event records and refit the candidate survival models."""

import numpy as np
import reconstruction as r
import survival as s
from distributions import fit_model
from io_utils import read_rows
from paths import DATA
from io_utils import write_rows as table, write_json as dump


def run(output):
    diagnostics = []
    fits = {}
    comparisons = []
    for key in ["OS_IP", "PFS_IP", "OS_PS", "PFS_PS"]:
        ipd, intervals, t, sv = r.reconstruct(key)
        source = read_rows(DATA / "reconstructed" / f"{key}_pseudo_ipd.csv")
        target = np.array([[float(x["time_months"]), int(x["event"])] for x in source])
        if not np.array_equal(ipd, target):
            raise AssertionError("Reconstruction differs: " + key)
        table(
            output / f"{key}_reconstructed.csv",
            [
                dict(
                    time_months=x,
                    event=int(e),
                    data_type="KM reconstructed marginal event record",
                )
                for x, e in ipd
            ],
        )
        table(output / f"{key}_risk_intervals.csv", intervals)
        diagnostics.append(
            dict(
                curve=key,
                n=len(ipd),
                events=int(ipd[:, 1].sum()),
                RMSE=float(np.sqrt(np.mean((r.km_values(ipd, t) - sv) ** 2))),
                exact_records_match=True,
            )
        )
    for background in ["P2023", "COHORT2026"]:
        fits[background] = {}
        for key in ["OS_IP", "PFS_IP", "OS_PS", "PFS_PS"]:
            fits[background][key] = {}
            pop = s.population(background, key.split("_")[1])
            for family in s.FAMILIES:
                record = s.fit(key, family, pop)
                fits[background][key][family] = record
                comparisons.append(
                    dict(
                        background=background,
                        curve=key,
                        family=family,
                        AIC=record["AIC"],
                        BIC=record["BIC"],
                        log_likelihood=record["log_likelihood_full"],
                        positive_information=record["positive_information"],
                        difference_from_supplied_AIC=record["AIC"]
                        - s.ARCH["results"][background][key][family]["AIC"],
                    )
                )
                print(
                    "Fit", background, key, family, round(record["AIC"], 5), flush=True
                )
    dump(output / "refitted_survival.json", fits)
    table(output / "reconstruction_diagnostics.csv", diagnostics)
    table(output / "candidate_fits.csv", comparisons)
    selected = []
    for bg in fits:
        for arm in ["IP", "PS"]:
            records = [
                record
                for key, ff in fits[bg].items()
                if key.endswith(arm)
                for record in ff.values()
            ]
            choice, pairs, _ = s.select_pair(records, s.population(bg, arm))
            selected.append(dict(background=bg, arm=arm, **choice))
            table(output / f"candidate_pairs_{bg}_{arm}.csv", pairs)
    table(output / "selected_survival_pairs.csv", selected)
    allcause = []
    for key in ["OS_IP", "PFS_IP", "OS_PS", "PFS_PS"]:
        t, e = s.data(key)
        for family in s.FAMILIES:
            record = fit_model(family, t, e)
            allcause.append(
                dict(
                    curve=key,
                    family=family,
                    AIC=record["AIC"],
                    BIC=record["BIC"],
                    difference_from_supplied_AIC=record["AIC"]
                    - s.ALLCAUSE_FITS[key][family]["AIC"],
                )
            )
    table(output / "allcause_candidate_fits.csv", allcause)
