from io_utils import read_rows as read, read_json as js
from paths import DATA, PARAMETERS
from pathlib import Path
import math, copy
import numpy as np
from scipy import optimize, special, stats


def logs(model, p, t):
    t = np.maximum(np.asarray(t, float), 1e-12)
    if model == "exponential":
        rate = np.exp(p[0])
        return (np.full_like(t, p[0]) - rate * t, -rate * t)
    if model == "weibull":
        shape, scale = np.exp(p)
        z = (t / scale) ** shape
        return (
            np.log(shape)
            - np.log(scale)
            + (shape - 1) * (np.log(t) - np.log(scale))
            - z,
            -z,
        )
    if model == "gompertz":
        rate = np.exp(p[0])
        shape = p[1]
        z = rate * t if abs(shape) < 1e-08 else rate * np.expm1(shape * t) / shape
        return (p[0] + shape * t - z, -z)
    if model == "lognormal":
        mu, logsigma = p
        sig = np.exp(logsigma)
        w = (np.log(t) - mu) / sig
        return (stats.norm.logpdf(w) - logsigma - np.log(t), special.log_ndtr(-w))
    if model == "loglogistic":
        shape, scale = np.exp(p)
        w = shape * (np.log(t) - np.log(scale))
        return (
            np.log(shape) - np.log(t) + w - 2 * np.logaddexp(0, w),
            -np.logaddexp(0, w),
        )
    if model == "gengamma":
        mu, logsigma, q = p
        sig = np.exp(logsigma)
        w = (np.log(t) - mu) / sig
        if abs(q) < 0.0001:
            return (stats.norm.logpdf(w) - logsigma - np.log(t), special.log_ndtr(-w))
        k = 1 / q**2
        v = q * w
        z = k * np.exp(np.minimum(v, 700))
        logf = (
            np.log(abs(q))
            - logsigma
            - np.log(t)
            - special.gammaln(k)
            + k * np.log(k)
            + k * v
            - z
        )
        surv = special.gammaincc(k, z) if q > 0 else special.gammainc(k, z)
        return (logf, np.log(np.maximum(surv, 1e-300)))
    raise ValueError(model)


def sf(model, p, t):
    return np.exp(logs(model, p, t)[1])


def numerical_hessian(f, p):
    p = np.asarray(p, float)
    n = len(p)
    h = 0.0001 * (1 + abs(p))
    H = np.zeros((n, n))
    f0 = f(p)
    for i in range(n):
        ei = np.zeros(n)
        ei[i] = h[i]
        H[i, i] = (f(p + ei) - 2 * f0 + f(p - ei)) / h[i] ** 2
        for j in range(i):
            ej = np.zeros(n)
            ej[j] = h[j]
            H[i, j] = H[j, i] = (
                f(p + ei + ej) - f(p + ei - ej) - f(p - ei + ej) + f(p - ei - ej)
            ) / (4 * h[i] * h[j])
    return H


import warnings


def fit_model(model, t, event):
    mu = np.mean(np.log(t))
    sig = max(np.std(np.log(t)), 0.4)
    if model == "exponential":
        starts = [[np.log(event.sum() / t.sum())]]
        bounds = [(-12, 2)]
    elif model in ["weibull", "loglogistic"]:
        starts = [[np.log(k), np.log(np.median(t))] for k in [0.6, 1.0, 1.5, 2.5]]
        bounds = [(-3, 3), (-3, 9)]
    elif model == "gompertz":
        starts = [[np.log(event.sum() / t.sum()), g] for g in [-0.03, 0, 0.02]]
        bounds = [(-12, 2), (-0.5, 0.2)]
    elif model == "lognormal":
        starts = [[mu, np.log(sig)], [np.log(np.median(t)), 0.0]]
        bounds = [(-3, 9), (-4, 3)]
    else:
        starts = [[mu, np.log(sig), q] for q in [-2, -1, -0.4, 0, 0.4, 1, 2]]
        bounds = [(-3, 9), (-4, 3), (-4, 4)]

    def nll(p):
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            logf, logS = logs(model, p, t)
            vals = event * logf + (1 - event) * logS
        return float(-np.sum(vals)) if np.all(np.isfinite(vals)) else 1e100

    fits = []
    for start in starts:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            f = optimize.minimize(
                nll,
                start,
                method="L-BFGS-B",
                bounds=bounds,
                options={"maxiter": 3000, "ftol": 1e-12, "gtol": 1e-07},
            )
        fits.append(f)
    fit = min(fits, key=lambda z: z.fun)
    check = optimize.minimize(
        nll,
        fit.x,
        method="Nelder-Mead",
        options={"maxiter": 3500, "xatol": 1e-08, "fatol": 1e-09},
    )
    if check.fun < fit.fun and all(
        (lo <= v <= hi for v, (lo, hi) in zip(check.x, bounds))
    ):
        fit = check
    H = numerical_hessian(nll, fit.x)
    eigen = np.linalg.eigvalsh(H)
    cov = np.linalg.inv(H) if np.all(eigen > 1e-07) else None
    proper = not (model == "gompertz" and fit.x[1] < 0)
    reason = (
        ""
        if proper
        else "Negative Gompertz shape implies a positive immortal fraction; no cure model prespecified."
    )
    return {
        "family": model,
        "params": fit.x.tolist(),
        "parameterization": {
            "exponential": ["log_rate_per_month"],
            "weibull": ["log_shape", "log_scale_months"],
            "gompertz": ["log_rate_per_month", "shape_per_month"],
            "lognormal": ["mu_log_months", "log_sigma"],
            "loglogistic": ["log_shape", "log_scale_months"],
            "gengamma": ["mu_log_months", "log_sigma", "Q_Pr entice".replace(" ", "")],
        }[model],
        "log_likelihood": -float(fit.fun),
        "AIC": 2 * len(fit.x) + 2 * float(fit.fun),
        "BIC": len(fit.x) * np.log(len(t)) + 2 * float(fit.fun),
        "optimizer_success": bool(fit.success),
        "optimizer_message": str(fit.message),
        "information_eigenvalues": eigen.tolist(),
        "covariance": None if cov is None else cov.tolist(),
        "proper_survival": proper,
        "ineligible_reason": reason,
        "multistart_best_nll_range": [
            float(min((x.fun for x in fits))),
            float(max((x.fun for x in fits))),
        ],
    }
