"""Shared cost-effectiveness summaries and strict positive-INMB counting."""

import numpy as np

WTP = 99665.0
ARMS = ["IP", "PS"]


def summarize(c, q, wtp=WTP, b=0.0):
    c = np.atleast_2d(c)
    q = np.atleast_2d(q)
    dc = c[:, 0] - c[:, 1] + b
    dq = q[:, 0] - q[:, 1]
    v = wtp * dq - dc
    n = len(v)
    p = float(np.mean(v > 0))
    return dict(
        n=n,
        C_IP_subtotal=float(c[:, 0].mean()),
        C_PS_subtotal=float(c[:, 1].mean()),
        Q_IP=float(q[:, 0].mean()),
        Q_PS=float(q[:, 1].mean()),
        delta_cost=float(dc.mean()),
        delta_QALY=float(dq.mean()),
        ICER=float(dc.mean() / dq.mean()) if dq.mean() != 0 else None,
        INMB=float(v.mean()),
        INHB=float(v.mean() / wtp) if wtp else None,
        p_CE=p if n > 1 else None,
        MCSE_p=float(np.sqrt(p * (1 - p) / n)) if n > 1 else None,
        MCSE_INMB=float(v.std(ddof=1) / np.sqrt(n)) if n > 1 else None,
        nonpositive_delta_QALY=int(np.count_nonzero(dq <= 0)),
    )
