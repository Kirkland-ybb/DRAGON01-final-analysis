from io_utils import read_rows as read, read_json as js
from paths import DATA, PARAMETERS
from io_utils import read_rows as read_csv, write_rows as write_csv

from pathlib import Path
import math, copy
import numpy as np
from scipy import optimize, special, stats

TOTAL_OS_EVENTS = {"OS_IP": 132, "OS_PS": 69}
TOTAL_EVENTS = dict(TOTAL_OS_EVENTS, PFS_IP=139, PFS_PS=70)
REPORTED_MEDIANS = {"OS_IP": 19.4, "OS_PS": 13.9, "PFS_IP": 11.2, "PFS_PS": 7.2}


def km_values(ipd, times):
    times = np.asarray(times, float)
    event_times = np.unique(ipd[ipd[:, 1] == 1, 0])
    ss = []
    s = 1.0
    for t in event_times:
        n = np.sum(ipd[:, 0] >= t - 1e-09)
        d = np.sum((abs(ipd[:, 0] - t) < 1e-09) & (ipd[:, 1] == 1))
        s *= 1 - d / n
        ss.append(s)
    index = np.searchsorted(event_times, times, side="right") - 1
    return np.where(index < 0, 1, np.asarray([1.0] + ss)[index + 1])


def simulate(tgrid, sg, nstart, sstart, lo, hi, c_count, d_count, censor_phase=0.5):
    if c_count:
        ct = lo + (np.arange(c_count) + censor_phase) / c_count * (hi - lo)
    else:
        ct = np.array([])
    records = []
    n = nstart
    s = sstart
    ci = 0
    de = 0
    for t, target in zip(tgrid, sg):
        while ci < len(ct) and ct[ci] < t:
            records.append((ct[ci], 0))
            n -= 1
            ci += 1
        need = int(np.floor(n * (1 - target / s) + 0.5)) if s > 0 else 0
        d = min(max(need, 0), d_count - de, n)
        if d:
            s *= 1 - d / n
            n -= d
            de += d
            records.extend([(float(t), 1)] * d)
    residual = d_count - de
    if residual:
        t = float(tgrid[-1])
        s *= 1 - residual / n
        n -= residual
        records.extend([(t, 1)] * residual)
    while ci < len(ct):
        records.append((ct[ci], 0))
        n -= 1
        ci += 1
    loc = np.array(records, float).reshape(-1, 2)
    et = np.unique(loc[loc[:, 1] == 1, 0])
    values = [sstart]
    sv = sstart
    for event_t in et:
        nr = nstart - np.sum(loc[:, 0] < event_t - 1e-09)
        dd = np.sum((abs(loc[:, 0] - event_t) < 1e-09) & (loc[:, 1] == 1))
        sv *= 1 - dd / nr
        values.append(sv)
    pred = np.asarray(values)[np.searchsorted(et, tgrid, side="right")]
    return (loc, s, n, pred, residual)


def reconstruct(
    key, censor_phase=0.5, offset_survival=0.0, enforce_pfs_count=True, beam_width=48
):
    data = read_csv(DATA / "digitized" / (key + "_pixels.csv"))
    risk = read_csv(DATA / "digitized" / (key + "_risk.csv"))
    t = np.array([float(r["time_months"]) for r in data])
    sv = np.array([float(r["survival"]) for r in data])
    if offset_survival:
        sv = np.maximum(0, np.minimum(1, sv + offset_survival))
        sv[0] = 1
    tr = np.array([float(r["time_months"]) for r in risk])
    nr = np.array([int(r["n_at_risk"]) for r in risk])
    constraints = TOTAL_EVENTS if enforce_pfs_count else TOTAL_OS_EVENTS
    beam = [(0.0, 1.0, 0, [], [])]
    for j in range(len(tr)):
        lo = tr[j]
        hi = tr[j + 1] if j + 1 < len(tr) else t[-1] + 0.0001
        idx = (t >= lo) & (t < hi)
        tt = t[idx]
        ss = sv[idx]
        if not len(tt):
            raise ValueError("Empty interval")
        nend = nr[j + 1] if j + 1 < len(tr) else 0
        loss = nr[j] - nend
        expanded = []
        for previous_cost, s, event_total, previous_records, previous_intervals in beam:
            candidates = range(loss + 1)
            if key in constraints and j == len(tr) - 1:
                remaining = constraints[key] - event_total
                if not 0 <= remaining <= loss:
                    continue
                candidates = [loss - remaining]
            for cc in candidates:
                dd = loss - cc
                if key in constraints and (
                    event_total + dd > constraints[key]
                    or event_total + dd + nend < constraints[key]
                ):
                    continue
                loc, send, nout, pred, residual = simulate(
                    tt, ss, nr[j], s, lo, hi, cc, dd, censor_phase
                )
                if nout != nend:
                    raise AssertionError("Risk-set accounting error")
                score = np.sum((pred - ss) ** 2) + 0.2 * len(tt) * (send - ss[-1]) ** 2
                row = {
                    "curve": key,
                    "interval_start": float(lo),
                    "interval_end": float(hi),
                    "risk_start": int(nr[j]),
                    "risk_end": int(nend),
                    "events": int(dd),
                    "censored": int(cc),
                    "survival_start": float(s),
                    "survival_end": float(send),
                    "interval_rmse": float(np.sqrt(np.mean((pred - ss) ** 2))),
                    "residual_events_at_last_read": int(residual),
                }
                expanded.append(
                    (
                        previous_cost + score,
                        send,
                        event_total + dd,
                        previous_records + loc.tolist(),
                        previous_intervals + [row],
                    )
                )
        expanded.sort(key=lambda v: v[0])
        beam = []
        seen = set()
        for state in expanded:
            code = (state[2], round(state[1], 7))
            if code in seen:
                continue
            seen.add(code)
            beam.append(state)
            if len(beam) >= beam_width:
                break
        if not beam:
            raise ValueError("No feasible reconstruction: " + key)
    cost, s, event_total, ipd, interval_rows = min(beam, key=lambda v: v[0])
    ipd = np.array(ipd, float)
    ipd = ipd[np.argsort(ipd[:, 0], kind="stable")]
    if len(ipd) != nr[0]:
        raise AssertionError("Wrong sample size")
    if key in constraints and int(ipd[:, 1].sum()) != constraints[key]:
        raise AssertionError("Event constraint")
    return (ipd, interval_rows, t, sv)
